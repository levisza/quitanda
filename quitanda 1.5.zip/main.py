from classes import Estoque, Usuario  # importação da classe usuario

def menu():
    estoque = Estoque()
    
    #login
    usuario = Usuario("joao", 1234)

    while True:
        print("=== QUITANDA ANHANGUERA ===")
        usuario_input = input("Insira seu Usuario: ")
        senha_input = int(input("Insira sua Senha: "))

        if usuario.autenticar(usuario_input, senha_input):
            print("Acesso Liberado")

            while True:
                print(" === MENU === \n 1 - Cadastro de Itens \n 2 - Estoque \n 3 - Sair")
                opcao = input("Escolha uma opção: ")

                if opcao == "1":
                    estoque.cadastro_itens()
                elif opcao == "2":
                    estoque.consultar_estoque()
                elif opcao == "3":
                    return  # fecha o programa
                else:
                    print("Opção inválida. Tente novamente.")
        else:
            print("Acesso Negado")

menu()

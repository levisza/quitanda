#classes - usuario
class Usuario:
    def __init__(self, nome, senha):
        self.nome = nome
        self.senha = senha

    def autenticar(self, usuario_input, senha_input):
        return self.nome == usuario_input and self.senha == senha_input

usuario_cadastrado = Usuario("joao", 1234)

#classes - estoque
class Estoque:
    def __init__(self):
        self.estoque = {}

    def cadastro_itens(self):
        produto = input("Digite o nome do produto: ")
        if produto in self.estoque:
            print("Produto já cadastrado")
            return
        quantidade = int(input("Digite a Quantidade: "))
        self.estoque[produto] = quantidade

    def consultar_estoque(self):
        if not self.estoque:
            print("Estoque Vazio")
        else:
            for key, value in self.estoque.items():
                print(f'Item = {key}, Quantidade = {value}')
# Validação do Usuário
usuario_cadastrado = Usuario("joao", 1234)